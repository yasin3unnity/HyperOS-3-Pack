#!/system/bin/sh
#
echo "======================================"
echo "    ✨ HyperOS 3 Action Menu ✨       "
echo "======================================"
echo " "
echo "⏳ Sedang membersihkan cache tema..."
echo " "

rm -rf /data/system/theme_magic/*
rm -rf /data/resource-cache/*

sleep 1.5
echo "✅ Cache berhasil dibersihkan!"
echo " "
echo "🚀 Silakan cek kembali tema kamu."
echo "======================================"

sleep 3