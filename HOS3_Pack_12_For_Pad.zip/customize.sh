#!/sbin/sh
#
keytest() {
  while true; do
    /system/bin/getevent -lc 1 | grep KEY_VOLUMEUP >/dev/null && sleep 0.5 && return 0
    /system/bin/getevent -lc 1 | grep KEY_VOLUMEDOWN >/dev/null && sleep 0.5 && return 1
  done
}

choose() {
  ui_print "  - [ Vol+ ] ✅ YA | [ Vol- ] ❌ TIDAK"
  if keytest; then return 0; else return 1; fi
}

ui_print " "
ui_print "======================================="
ui_print "    ✨ HyperOS 3 Custom Install ✨    "
ui_print "    By: @yasin3unnity 🚀     "
ui_print "    HyperOS 2.0.1.0 - 2.0.200.0   "
ui_print "======================================="
ui_print " "


ui_print " "
ui_print " jika posisi rom berada di versi HyperOS 3.0.1.0 atau lebih baru, silahkan pilih ikon dan settings saja"
ui_print " "


# Module Info
MODNAME=$(grep_prop name $MODPATH/module.prop)
MODVER=$(grep_prop version $MODPATH/module.prop)
DV=$(grep_prop author $MODPATH/module.prop)

# Device Info
Device=$(getprop ro.product.device)
Model=$(getprop ro.product.model)
Brand=$(getprop ro.product.brand)
Architecture=$(getprop ro.product.cpu.abi)
SDK=$(getprop ro.system.build.version.sdk)
Android=$(getprop ro.system.build.version.release)
Type=$(getprop ro.system.build.type)
Built=$(getprop ro.system.build.date)
Time=$(date "+%d, %b - %H:%M %Z")
HyperOS=$(getprop ro.miui.ui.version.name)
OS_Ver=$(getprop ro.build.version.incremental)

#Output Info
ui_print "-------------------------------------"
ui_print " Fetching module & device info..."
ui_print "-------------------------------------"
sleep 1.5
ui_print "- Author       : $DV"
sleep 0.3
ui_print "- Module       : $MODNAME"
sleep 0.3
ui_print "- Version      : $MODVER"
sleep 0.3
ui_print "- Device       : $Model [$Device]"
sleep 0.3
ui_print "- Brand        : $Brand"
sleep 0.3
ui_print "- Android      : $Android (SDK $SDK)"
sleep 0.3
ui_print "- HyperOS      : $HyperOS ($OS_Ver)"
sleep 0.3
ui_print "- CPU Arch     : $Architecture"
sleep 0.3
ui_print "- Build Type   : $Type"
sleep 0.3
ui_print "- Build Time   : $Built"
sleep 0.3
ui_print "- Installed at : $Time"
sleep 0.3


ui_print " "
ui_print "⚙️ [?] Pasang Tema Settings?"
if choose; then
  ui_print "  -> ✅ Settings dipilih"
  S_STAT="✅"
else
  ui_print "  -> ❌ Melewati Settings"
  S_STAT="❌"
  rm -rf $MODPATH/system/media/theme/default/com.android.settings
fi

ui_print " "

ui_print "📱 [?] Pasang Tema SystemUI?"
if choose; then
  ui_print "  -> ✅ SystemUI dipilih"
  U_STAT="✅"
else
  ui_print "  -> ❌ Melewati SystemUI"
  U_STAT="❌"
  rm -rf $MODPATH/system/media/theme/default/com.android.systemui
fi

ui_print " "

ui_print "🔌 [?] Pasang Tema SystemUI Plugin?"
if choose; then
  ui_print "  -> ✅ Plugin dipilih"
  P_STAT="✅"
else
  ui_print "  -> ❌ Melewati Plugin"
  P_STAT="❌"
  rm -rf $MODPATH/system/media/theme/default/miui.systemui.plugin
fi

ui_print " "

ui_print "🎨 [?] Pasang HyperOS 3 Icons?"
if choose; then
  ui_print "  -> ✅ Icons dipilih"
  I_STAT="✅"
else
  ui_print "  -> ❌ Melewati Icons"
  I_STAT="❌"
  rm -rf $MODPATH/system/media/theme/default/icons
fi

ui_print " "

ui_print "📂 [?] Pasang UI File Explorer?"
if choose; then
  ui_print "  -> ✅ UI dipilih"
  Y_STAT="✅"
else
  ui_print " -> ❌ Melewati UI"
  Y_STAT="❌"
  rm -rf $MODPATH/system/media/theme/default/com.mi.android.globalFileexplorer
fi
ui_print " "

MOD_STATUS=" [ Settings $S_STAT][ SystemUI $U_STAT][ SystemUI Plug $P_STAT][ Icons $I_STAT][ UI File $Y_STAT]"
NEW_DESC="$MOD_STATUS ⟨New Featured⟩  ©xendr4x | ©VK Themes | modified by ©yasin3unnity | Do not flash on HyperOS 3.0.1.0 Or Newer"

sed -i "s/^description=.*/description=$NEW_DESC/g" $MODPATH/module.prop

ui_print " "
ui_print "==============================="
ui_print "   🛠️ Memproses script tambahan..."
ui_print "==============================="

ui_print " - Done"
sleep 1
ui_print " - Starting additional script"
sleep 1

if [ -d "$MODPATH/system/folder" ]; then
    mv $MODPATH/system/folder $MODPATH/system/product
fi

set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/customize.sh 0 0 0755

ui_print " "
ui_print "==============================="
ui_print "    ✅ INSTALASI SELESAI!     "
ui_print "      SILAKAN REBOOT HP       "
ui_print "==============================="